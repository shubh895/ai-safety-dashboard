import { IncidentDashboard } from "@/components/incident-dashboard"

export default function Home() {
  return (
    <main className="min-h-screen bg-gradient-to-b from-slate-50 to-slate-100 dark:from-slate-900 dark:to-slate-800 p-4 md:p-8">
      <div className="container mx-auto">
        <h1 className="text-4xl font-bold mb-2 text-center bg-gradient-to-r from-purple-600 to-pink-600 text-transparent bg-clip-text">
          AI Safety Incident Dashboard
        </h1>
        <p className="text-center text-muted-foreground mb-8">Monitor, track, and report AI safety incidents</p>
        <IncidentDashboard />
      </div>
    </main>
  )
}
