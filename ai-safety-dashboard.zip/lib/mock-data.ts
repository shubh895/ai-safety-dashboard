import type { Incident } from "./types"

export const mockIncidents: Incident[] = [
  {
    id: 1,
    title: "Biased Recommendation Algorithm",
    description:
      "Algorithm consistently favored certain demographics in job recommendations, leading to potential discrimination issues. The bias was detected during a routine audit of recommendation patterns across different user groups.",
    severity: "Medium",
    reported_at: "2025-03-15T10:00:00Z",
  },
  {
    id: 2,
    title: "LLM Hallucination in Critical Info",
    description:
      "LLM provided incorrect safety procedure information when asked about emergency protocols in a manufacturing setting. This could have led to dangerous situations if the information had been followed in a real emergency scenario.",
    severity: "High",
    reported_at: "2025-04-01T14:30:00Z",
  },
  {
    id: 3,
    title: "Minor Data Leak via Chatbot",
    description:
      "Chatbot inadvertently exposed non-sensitive user metadata in its responses. While no personally identifiable information was revealed, the incident highlights a potential vulnerability in the system's data handling protocols.",
    severity: "Low",
    reported_at: "2025-03-20T09:15:00Z",
  },
  {
    id: 4,
    title: "Facial Recognition False Positive",
    description:
      "Security system incorrectly identified an individual as a person of interest, triggering unnecessary security protocols. The incident was resolved quickly but raises concerns about the accuracy of the facial recognition algorithms in diverse environments.",
    severity: "Medium",
    reported_at: "2025-03-25T16:45:00Z",
  },
  {
    id: 5,
    title: "AI-Generated Content Misattribution",
    description:
      "Content generation system created material that closely resembled existing copyrighted work without proper attribution. This raises concerns about potential copyright infringement and the need for better content verification systems.",
    severity: "Medium",
    reported_at: "2025-03-18T11:20:00Z",
  },
  {
    id: 6,
    title: "Critical System Vulnerability",
    description:
      "AI security audit system failed to detect a significant vulnerability in a client's infrastructure, which was later exploited by attackers. The incident resulted in temporary system downtime and potential data exposure.",
    severity: "High",
    reported_at: "2025-03-30T08:10:00Z",
  },
]
