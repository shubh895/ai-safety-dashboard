"use client"

import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import type { SeverityLevel } from "@/lib/types"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { PlusCircle, SortAsc, SortDesc, Filter } from "lucide-react"
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Skeleton } from "@/components/ui/skeleton"

interface FilterControlsProps {
  severityFilter: SeverityLevel | "All"
  setSeverityFilter: (filter: SeverityLevel | "All") => void
  sortOrder: "newest" | "oldest"
  setSortOrder: (order: "newest" | "oldest") => void
  showForm: boolean
  setShowForm: (show: boolean) => void
  isLoading: boolean
}

export function FilterControls({
  severityFilter,
  setSeverityFilter,
  sortOrder,
  setSortOrder,
  showForm,
  setShowForm,
  isLoading,
}: FilterControlsProps) {
  if (isLoading) {
    return (
      <Card>
        <CardContent className="p-4">
          <div className="flex flex-col md:flex-row gap-4 items-start md:items-center justify-between">
            <div className="flex flex-col sm:flex-row gap-4 w-full md:w-auto">
              <Skeleton className="h-10 w-[180px]" />
              <Skeleton className="h-10 w-[180px]" />
            </div>
            <Skeleton className="h-10 w-[180px]" />
          </div>
        </CardContent>
      </Card>
    )
  }

  return (
    <Card className="border-none shadow-md bg-white/80 dark:bg-slate-800/80 backdrop-blur-sm">
      <CardContent className="p-4">
        <div className="flex flex-col md:flex-row gap-4 items-start md:items-center justify-between">
          <div className="flex flex-col sm:flex-row gap-4 w-full md:w-auto">
            <div className="space-y-1">
              <label htmlFor="severity-filter" className="text-sm font-medium flex items-center gap-1">
                <Filter className="h-4 w-4 text-purple-500" />
                Filter by Severity
              </label>
              <Tabs
                value={severityFilter}
                onValueChange={(value) => setSeverityFilter(value as SeverityLevel | "All")}
                className="w-full"
              >
                <TabsList className="grid grid-cols-4 w-full">
                  <TabsTrigger
                    value="All"
                    className="data-[state=active]:bg-primary data-[state=active]:text-primary-foreground"
                  >
                    All
                  </TabsTrigger>
                  <TabsTrigger value="Low" className="data-[state=active]:bg-green-500 data-[state=active]:text-white">
                    Low
                  </TabsTrigger>
                  <TabsTrigger
                    value="Medium"
                    className="data-[state=active]:bg-yellow-500 data-[state=active]:text-white"
                  >
                    Medium
                  </TabsTrigger>
                  <TabsTrigger value="High" className="data-[state=active]:bg-red-500 data-[state=active]:text-white">
                    High
                  </TabsTrigger>
                </TabsList>
              </Tabs>
            </div>

            <div className="space-y-1">
              <label htmlFor="sort-order" className="text-sm font-medium flex items-center gap-1">
                {sortOrder === "newest" ? (
                  <SortDesc className="h-4 w-4 text-purple-500" />
                ) : (
                  <SortAsc className="h-4 w-4 text-purple-500" />
                )}
                Sort by Date
              </label>
              <Select value={sortOrder} onValueChange={(value) => setSortOrder(value as "newest" | "oldest")}>
                <SelectTrigger id="sort-order" className="w-[180px] border-purple-200 focus:ring-purple-500">
                  <SelectValue placeholder="Select sort order" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="newest">
                    <div className="flex items-center gap-2">
                      <SortDesc className="h-4 w-4" />
                      <span>Newest First</span>
                    </div>
                  </SelectItem>
                  <SelectItem value="oldest">
                    <div className="flex items-center gap-2">
                      <SortAsc className="h-4 w-4" />
                      <span>Oldest First</span>
                    </div>
                  </SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          <Button
            onClick={() => setShowForm(!showForm)}
            className={`w-full sm:w-auto transition-all duration-300 ${showForm ? "bg-red-500 hover:bg-red-600" : "bg-purple-600 hover:bg-purple-700"}`}
          >
            <PlusCircle className="mr-2 h-4 w-4" />
            {showForm ? "Hide Form" : "Report New Incident"}
          </Button>
        </div>
      </CardContent>
    </Card>
  )
}
