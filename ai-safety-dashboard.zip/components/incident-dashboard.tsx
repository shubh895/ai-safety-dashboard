"use client"

import { useState, useEffect } from "react"
import { IncidentList } from "./incident-list"
import { NewIncidentForm } from "./new-incident-form"
import { FilterControls } from "./filter-controls"
import { DashboardStats } from "./dashboard-stats"
import { mockIncidents } from "@/lib/mock-data"
import type { Incident, SeverityLevel } from "@/lib/types"
import { useToast } from "@/hooks/use-toast"
import confetti from "canvas-confetti"

export function IncidentDashboard() {
  const [incidents, setIncidents] = useState<Incident[]>(mockIncidents)
  const [filteredIncidents, setFilteredIncidents] = useState<Incident[]>(mockIncidents)
  const [severityFilter, setSeverityFilter] = useState<SeverityLevel | "All">("All")
  const [sortOrder, setSortOrder] = useState<"newest" | "oldest">("newest")
  const [showForm, setShowForm] = useState(false)
  const [isLoading, setIsLoading] = useState(true)
  const { toast } = useToast()

  // Simulate loading state
  useEffect(() => {
    const timer = setTimeout(() => {
      setIsLoading(false)
    }, 1000)
    return () => clearTimeout(timer)
  }, [])

  // Apply filters and sorting
  useEffect(() => {
    let result = [...incidents]

    // Apply severity filter
    if (severityFilter !== "All") {
      result = result.filter((incident) => incident.severity === severityFilter)
    }

    // Apply sorting
    result.sort((a, b) => {
      const dateA = new Date(a.reported_at).getTime()
      const dateB = new Date(b.reported_at).getTime()
      return sortOrder === "newest" ? dateB - dateA : dateA - dateB
    })

    setFilteredIncidents(result)
  }, [incidents, severityFilter, sortOrder])

  // Add new incident
  const handleAddIncident = (incident: Omit<Incident, "id" | "reported_at">) => {
    const newIncident: Incident = {
      ...incident,
      id: incidents.length + 1,
      reported_at: new Date().toISOString(),
    }

    setIncidents((prev) => [...prev, newIncident])
    setShowForm(false)

    // Show success toast
    toast({
      title: "Incident Reported",
      description: "The new incident has been successfully added to the dashboard.",
      variant: "success",
    })

    // Trigger confetti effect
    confetti({
      particleCount: 100,
      spread: 70,
      origin: { y: 0.6 },
    })
  }

  // Calculate stats
  const stats = {
    total: incidents.length,
    high: incidents.filter((i) => i.severity === "High").length,
    medium: incidents.filter((i) => i.severity === "Medium").length,
    low: incidents.filter((i) => i.severity === "Low").length,
  }

  return (
    <div className="space-y-6">
      <DashboardStats stats={stats} isLoading={isLoading} />

      <FilterControls
        severityFilter={severityFilter}
        setSeverityFilter={setSeverityFilter}
        sortOrder={sortOrder}
        setSortOrder={setSortOrder}
        showForm={showForm}
        setShowForm={setShowForm}
        isLoading={isLoading}
      />

      {showForm && (
        <div className="bg-card rounded-lg p-6 shadow-lg border border-border animate-in slide-in-from-top duration-300">
          <h2 className="text-xl font-semibold mb-4 flex items-center">
            <span className="bg-purple-100 dark:bg-purple-900 text-purple-600 dark:text-purple-300 p-2 rounded-full mr-2">
              <svg
                xmlns="http://www.w3.org/2000/svg"
                width="20"
                height="20"
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                strokeWidth="2"
                strokeLinecap="round"
                strokeLinejoin="round"
                className="lucide lucide-clipboard-plus"
              >
                <rect width="8" height="4" x="8" y="2" rx="1" ry="1" />
                <path d="M16 4h2a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2h2" />
                <path d="M12 11v6" />
                <path d="M9 14h6" />
              </svg>
            </span>
            Report New Incident
          </h2>
          <NewIncidentForm onSubmit={handleAddIncident} onCancel={() => setShowForm(false)} />
        </div>
      )}

      <IncidentList incidents={filteredIncidents} isLoading={isLoading} />
    </div>
  )
}
