"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import type { SeverityLevel } from "@/lib/types"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { Label } from "@/components/ui/label"
import { AlertCircle, AlertTriangle, AlertOctagon } from "lucide-react"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { motion } from "framer-motion"

interface NewIncidentFormProps {
  onSubmit: (incident: { title: string; description: string; severity: SeverityLevel }) => void
  onCancel: () => void
}

export function NewIncidentForm({ onSubmit, onCancel }: NewIncidentFormProps) {
  const [title, setTitle] = useState("")
  const [description, setDescription] = useState("")
  const [severity, setSeverity] = useState<SeverityLevel | "">("")
  const [errors, setErrors] = useState<{ title?: string; description?: string; severity?: string }>({})

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()

    // Validate form
    const newErrors: { title?: string; description?: string; severity?: string } = {}

    if (!title.trim()) {
      newErrors.title = "Title is required"
    }

    if (!description.trim()) {
      newErrors.description = "Description is required"
    }

    if (!severity) {
      newErrors.severity = "Severity is required"
    }

    if (Object.keys(newErrors).length > 0) {
      setErrors(newErrors)
      return
    }

    // Submit form if validation passes
    onSubmit({
      title,
      description,
      severity: severity as SeverityLevel,
    })

    // Reset form
    setTitle("")
    setDescription("")
    setSeverity("")
    setErrors({})
  }

  return (
    <motion.form
      onSubmit={handleSubmit}
      className="space-y-4"
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ duration: 0.3 }}
    >
      {(errors.title || errors.description || errors.severity) && (
        <Alert variant="destructive">
          <AlertCircle className="h-4 w-4" />
          <AlertDescription>Please fix the errors in the form before submitting.</AlertDescription>
        </Alert>
      )}

      <div className="space-y-2">
        <label htmlFor="title" className="text-sm font-medium">
          Title <span className="text-red-500">*</span>
        </label>
        <Input
          id="title"
          value={title}
          onChange={(e) => setTitle(e.target.value)}
          placeholder="Enter incident title"
          className={`${errors.title ? "border-red-500 focus-visible:ring-red-500" : "focus-visible:ring-purple-500"} transition-all duration-200`}
        />
        {errors.title && (
          <motion.p className="text-xs text-red-500" initial={{ opacity: 0, y: -10 }} animate={{ opacity: 1, y: 0 }}>
            {errors.title}
          </motion.p>
        )}
      </div>

      <div className="space-y-2">
        <label htmlFor="description" className="text-sm font-medium">
          Description <span className="text-red-500">*</span>
        </label>
        <Textarea
          id="description"
          value={description}
          onChange={(e) => setDescription(e.target.value)}
          placeholder="Provide detailed information about the incident"
          rows={4}
          className={`${errors.description ? "border-red-500 focus-visible:ring-red-500" : "focus-visible:ring-purple-500"} transition-all duration-200`}
        />
        {errors.description && (
          <motion.p className="text-xs text-red-500" initial={{ opacity: 0, y: -10 }} animate={{ opacity: 1, y: 0 }}>
            {errors.description}
          </motion.p>
        )}
      </div>

      <div className="space-y-3">
        <div className="flex items-center justify-between">
          <label className="text-sm font-medium">
            Severity <span className="text-red-500">*</span>
          </label>
          {errors.severity && (
            <motion.p className="text-xs text-red-500" initial={{ opacity: 0, y: -10 }} animate={{ opacity: 1, y: 0 }}>
              {errors.severity}
            </motion.p>
          )}
        </div>

        <RadioGroup
          value={severity}
          onValueChange={(value) => setSeverity(value as SeverityLevel)}
          className="flex flex-col sm:flex-row gap-2"
        >
          <div
            className={`flex items-center space-x-2 border rounded-md p-3 transition-all duration-200 ${severity === "Low" ? "bg-green-50 border-green-200 dark:bg-green-900/20" : "hover:bg-muted"}`}
          >
            <RadioGroupItem value="Low" id="severity-low" />
            <Label htmlFor="severity-low" className="flex items-center gap-2 cursor-pointer">
              <AlertCircle className="h-4 w-4 text-green-600" />
              Low
            </Label>
          </div>

          <div
            className={`flex items-center space-x-2 border rounded-md p-3 transition-all duration-200 ${severity === "Medium" ? "bg-yellow-50 border-yellow-200 dark:bg-yellow-900/20" : "hover:bg-muted"}`}
          >
            <RadioGroupItem value="Medium" id="severity-medium" />
            <Label htmlFor="severity-medium" className="flex items-center gap-2 cursor-pointer">
              <AlertTriangle className="h-4 w-4 text-yellow-600" />
              Medium
            </Label>
          </div>

          <div
            className={`flex items-center space-x-2 border rounded-md p-3 transition-all duration-200 ${severity === "High" ? "bg-red-50 border-red-200 dark:bg-red-900/20" : "hover:bg-muted"}`}
          >
            <RadioGroupItem value="High" id="severity-high" />
            <Label htmlFor="severity-high" className="flex items-center gap-2 cursor-pointer">
              <AlertOctagon className="h-4 w-4 text-red-600" />
              High
            </Label>
          </div>
        </RadioGroup>
      </div>

      <div className="flex justify-end gap-2 pt-4">
        <Button
          type="button"
          variant="outline"
          onClick={onCancel}
          className="border-purple-200 text-purple-700 hover:bg-purple-50 hover:text-purple-800"
        >
          Cancel
        </Button>
        <Button type="submit" className="bg-purple-600 hover:bg-purple-700">
          Submit Incident
        </Button>
      </div>
    </motion.form>
  )
}
