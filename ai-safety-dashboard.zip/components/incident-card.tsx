"use client"

import { useState } from "react"
import type { Incident } from "@/lib/types"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardFooter, CardHeader } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { ChevronDown, ChevronUp, Calendar, AlertTriangle, AlertCircle, AlertOctagon } from "lucide-react"
import { formatDate } from "@/lib/utils"
import { Skeleton } from "@/components/ui/skeleton"
import { motion } from "framer-motion"

interface IncidentCardProps {
  incident?: Incident
  isLoading: boolean
  animationDelay?: number
}

export function IncidentCard({ incident, isLoading, animationDelay = 0 }: IncidentCardProps) {
  const [expanded, setExpanded] = useState(false)

  if (isLoading) {
    return (
      <Card className="overflow-hidden transition-all duration-200 hover:shadow-md">
        <CardHeader className="p-4 pb-0">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
            <Skeleton className="h-6 w-3/4" />
            <div className="flex items-center gap-3">
              <Skeleton className="h-5 w-16" />
              <Skeleton className="h-5 w-32" />
            </div>
          </div>
        </CardHeader>
        <CardContent className="p-4">
          <Skeleton className="h-4 w-full" />
        </CardContent>
        <CardFooter className="p-4 pt-0 flex justify-end">
          <Skeleton className="h-8 w-28" />
        </CardFooter>
      </Card>
    )
  }

  if (!incident) return null

  const severityConfig = {
    Low: {
      color: "bg-green-100 text-green-800 hover:bg-green-100 border-green-200",
      icon: AlertCircle,
      gradient: "from-green-50 to-white dark:from-green-900/20 dark:to-slate-800/50",
    },
    Medium: {
      color: "bg-yellow-100 text-yellow-800 hover:bg-yellow-100 border-yellow-200",
      icon: AlertTriangle,
      gradient: "from-yellow-50 to-white dark:from-yellow-900/20 dark:to-slate-800/50",
    },
    High: {
      color: "bg-red-100 text-red-800 hover:bg-red-100 border-red-200",
      icon: AlertOctagon,
      gradient: "from-red-50 to-white dark:from-red-900/20 dark:to-slate-800/50",
    },
  }[incident.severity]

  const SeverityIcon = severityConfig.icon

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.3, delay: animationDelay }}
    >
      <Card
        className={`overflow-hidden transition-all duration-200 hover:shadow-md bg-gradient-to-r ${severityConfig.gradient} border-l-4`}
        style={{ borderLeftColor: severityConfig.color.split(" ")[1].replace("text-", "") }}
      >
        <CardHeader className="p-4 pb-0">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
            <h3 className="text-lg font-semibold flex items-center gap-2">
              <SeverityIcon className={`h-5 w-5 ${severityConfig.color.split(" ")[1]}`} />
              {incident.title}
            </h3>
            <div className="flex items-center gap-3">
              <Badge variant="outline" className={severityConfig.color}>
                {incident.severity}
              </Badge>
              <span className="text-sm text-muted-foreground flex items-center gap-1">
                <Calendar className="h-3 w-3" />
                {formatDate(incident.reported_at)}
              </span>
            </div>
          </div>
        </CardHeader>
        <CardContent className="p-4">
          {expanded && (
            <motion.div
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: "auto" }}
              exit={{ opacity: 0, height: 0 }}
              transition={{ duration: 0.3 }}
              className="mt-2 text-sm text-muted-foreground border-l-2 border-muted pl-4 py-2"
            >
              {incident.description}
            </motion.div>
          )}
        </CardContent>
        <CardFooter className="p-4 pt-0 flex justify-end">
          <Button
            variant="ghost"
            size="sm"
            onClick={() => setExpanded(!expanded)}
            className={`text-sm transition-colors duration-200 ${expanded ? severityConfig.color : ""}`}
          >
            {expanded ? (
              <>
                <ChevronUp className="h-4 w-4 mr-1" />
                Hide Details
              </>
            ) : (
              <>
                <ChevronDown className="h-4 w-4 mr-1" />
                View Details
              </>
            )}
          </Button>
        </CardFooter>
      </Card>
    </motion.div>
  )
}
