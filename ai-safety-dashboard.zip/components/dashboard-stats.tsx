import { Card, CardContent } from "@/components/ui/card"
import { AlertTriangle, AlertCircle, AlertOctagon, ClipboardList } from "lucide-react"

interface DashboardStatsProps {
  stats: {
    total: number
    high: number
    medium: number
    low: number
  }
  isLoading: boolean
}

export function DashboardStats({ stats, isLoading }: DashboardStatsProps) {
  const statCards = [
    {
      title: "Total Incidents",
      value: stats.total,
      icon: ClipboardList,
      color: "bg-blue-50 text-blue-600 dark:bg-blue-900/30 dark:text-blue-300",
      loading: isLoading,
    },
    {
      title: "High Severity",
      value: stats.high,
      icon: AlertOctagon,
      color: "bg-red-50 text-red-600 dark:bg-red-900/30 dark:text-red-300",
      loading: isLoading,
    },
    {
      title: "Medium Severity",
      value: stats.medium,
      icon: AlertTriangle,
      color: "bg-yellow-50 text-yellow-600 dark:bg-yellow-900/30 dark:text-yellow-300",
      loading: isLoading,
    },
    {
      title: "Low Severity",
      value: stats.low,
      icon: AlertCircle,
      color: "bg-green-50 text-green-600 dark:bg-green-900/30 dark:text-green-300",
      loading: isLoading,
    },
  ]

  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
      {statCards.map((stat, index) => (
        <Card
          key={index}
          className="overflow-hidden border-t-4 hover:shadow-lg transition-all duration-200"
          style={{ borderTopColor: stat.color.split(" ")[1].replace("text-", "") }}
        >
          <CardContent className="p-6">
            <div className="flex justify-between items-center">
              <div>
                <p className="text-sm font-medium text-muted-foreground">{stat.title}</p>
                {stat.loading ? (
                  <div className="h-8 w-16 bg-muted animate-pulse rounded mt-1"></div>
                ) : (
                  <p className="text-3xl font-bold mt-1">{stat.value}</p>
                )}
              </div>
              <div className={`p-3 rounded-full ${stat.color}`}>
                <stat.icon className="h-6 w-6" />
              </div>
            </div>
          </CardContent>
        </Card>
      ))}
    </div>
  )
}
