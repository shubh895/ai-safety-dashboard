import type { Incident } from "@/lib/types"
import { IncidentCard } from "./incident-card"
import { SearchX } from "lucide-react"

interface IncidentListProps {
  incidents: Incident[]
  isLoading: boolean
}

export function IncidentList({ incidents, isLoading }: IncidentListProps) {
  if (isLoading) {
    return (
      <div className="space-y-4">
        {[1, 2, 3].map((i) => (
          <IncidentCard key={i} isLoading={true} />
        ))}
      </div>
    )
  }

  if (incidents.length === 0) {
    return (
      <div className="text-center p-12 bg-card rounded-lg border border-border flex flex-col items-center justify-center">
        <div className="bg-muted p-4 rounded-full mb-4">
          <SearchX className="h-12 w-12 text-muted-foreground" />
        </div>
        <h3 className="text-xl font-semibold mb-2">No incidents found</h3>
        <p className="text-muted-foreground max-w-md">
          No incidents match your current filter criteria. Try changing your filters or add a new incident.
        </p>
      </div>
    )
  }

  return (
    <div className="space-y-4">
      {incidents.map((incident, index) => (
        <IncidentCard key={incident.id} incident={incident} isLoading={false} animationDelay={index * 0.1} />
      ))}
    </div>
  )
}
